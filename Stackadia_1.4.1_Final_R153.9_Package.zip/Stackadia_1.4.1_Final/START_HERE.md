# Stackadia 1.4.1 Final

**Phase 6.18.9 / R153.9 — Stackadia 1.4.1 Maintenance Final**

This package is the canonical Stackadia 1.4.1 maintenance release. It promotes the accepted R153.8 candidate after the complete hands-on maintenance gate passed.

## Applications

- `Stackadia_1.4.1_Final_Standalone.html` — authoritative authoring application and full Browse runtime.
- `Stackadia_1.4.1_Final_Lightweight_Player.html` — aligned Browse-only Player for XStack projects.
- `Stackadia_Speech_Demonstration_1.4.1.xstack` — retained speech demonstration and compatibility check.

Open either HTML application directly in a supported desktop browser. The applications are self-contained and do not require installation.

## Documentation

- `Stackadia_1.4.1_Final_User_Guide.html`
- `Stackadia_Script_1.2_Dictionary.html`
- `RELEASE_NOTES.md`
- `FINAL_RELEASE_RECORD.md`
- `SOURCE_AND_BUILD.md`

## Integrity

Run `sha256sum -c SHA256SUMS.txt` from this folder, or use an equivalent SHA-256 verifier. Preserve the supplied license, corresponding source, and third-party notices when redistributing Stackadia.

Web App and PWA builders remain frozen development references outside the Stackadia 1.4.1 production boundary.
