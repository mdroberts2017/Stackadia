# Stackadia 1.4.1 Final Release Notes

**Version:** 1.4.1  
**Phase:** 6.18.9  
**Revision:** R153.9 — Stackadia 1.4.1 Maintenance Final  
**Date:** September 18, 2026

Stackadia 1.4.1 is a focused maintenance release that corrects Author-mode editing in Responsive layout projects.

## Corrected behavior

Unlocked Buttons, Labels, and other ordinary objects can now be:

- dragged with the Select tool;
- repositioned with Arrow and Shift+Arrow nudges;
- resized with selection handles;
- aligned and distributed using their visible responsive geometry; and
- matched to another object’s visible width or height.

These operations update the active responsive rule. Percentage positions and sizes update their percentage values; trailing anchors update margins. Moving an axis that was centered converts it to an explicit percentage position. Children managed by horizontal, vertical, or grid flow remain controlled by the parent layout.

## Player alignment

The paired Lightweight Player carries matching 1.4.1 Final/R153.9 identity and is byte-identical to the Player embedded in Standalone. Player has no Author mode, so its executable playback runtime is unchanged from the accepted R153.8 candidate except for Final identity markers.

## Compatibility

- Project schema 47, XStack 3, Stackadia Script 1.2, and Extension SDK 3 are unchanged.
- The accepted speech host service and Script runtime worker are unchanged.
- Existing fixed and scale-layout projects retain their established behavior.
- Stackadia 1.4 Final/R153.7 and the accepted R153.8 candidate remain immutable historical artifacts.
- Web App and PWA output remain frozen development references outside production qualification.

## Qualification

- The R153.8 hands-on maintenance checklist passed in full.
- Automated correction, preservation, syntax, Player-pairing, and Final-promotion checks passed.
- The responsive author-geometry correction is byte-identical to accepted R153.8.
- External and Standalone-embedded Final Player bytes are identical.
- The Final package is deterministic and passes checksum and clean-extraction verification.
