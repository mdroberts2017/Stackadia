# Source and Build Notes

Stackadia is licensed under GPL-3.0-or-later. The Final package includes application artifacts, tests, corresponding source, license, and third-party notices.

R153.9 is generated from the exact accepted R153.8 RC1 artifacts. The build verifies their SHA-256 hashes before applying Final identity and packaging transformations:

```text
python3 tools/build_r153_9.py
python3 tools/generate_r153_9_docs.py
python3 tools/package_r153_9.py
```

Run the Final promotion check with Node.js:

```text
node tests/R153.9_Maintenance_Final_Promotion_Tests.mjs
```

The corresponding-source archive retains the R153.8 focused test and the frozen R153.7 suites. Combined automated qualification reports 236 passed and 0 failed.

The complete application implementation remains embedded in the self-contained Standalone and Lightweight Player HTML artifacts. Embedded inert modules retain their source text and license headers.
