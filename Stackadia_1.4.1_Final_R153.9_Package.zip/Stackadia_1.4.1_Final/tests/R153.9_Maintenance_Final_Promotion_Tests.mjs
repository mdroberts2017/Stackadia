import fs from "node:fs";
import { createHash } from "node:crypto";
import { gunzipSync } from "node:zlib";
import vm from "node:vm";

const releaseRoot = new URL("../", import.meta.url);
const sourceRoot = new URL("../../../", import.meta.url);
const rcRoot = new URL("branch/Stackadia_Phase6.18.8_R153.8/", sourceRoot);
const standalone = fs.readFileSync(new URL("Stackadia_1.4.1_Final_Standalone.html", releaseRoot), "utf8");
const player = fs.readFileSync(new URL("Stackadia_1.4.1_Final_Lightweight_Player.html", releaseRoot), "utf8");
const guide = fs.readFileSync(new URL("Stackadia_1.4.1_Final_User_Guide.html", releaseRoot), "utf8");
const dictionary = fs.readFileSync(new URL("Stackadia_Script_1.2_Dictionary.html", releaseRoot), "utf8");
const demo = fs.readFileSync(new URL("Stackadia_Speech_Demonstration_1.4.1.xstack", releaseRoot));
const rcStandaloneBytes = fs.readFileSync(new URL("Stackadia_1.4.1_RC1_Standalone.html", rcRoot));
const rcStandalone = rcStandaloneBytes.toString("utf8");
const rcPlayerBytes = fs.readFileSync(new URL("Stackadia_1.4.1_RC1_Lightweight_Player.html", rcRoot));
const rcPlayer = rcPlayerBytes.toString("utf8");
const rcDemo = fs.readFileSync(new URL("Stackadia_Speech_Demonstration_1.4.1_RC1.xstack", rcRoot));

let passed = 0;
const checks = [];
const sha256 = (value) => createHash("sha256").update(value).digest("hex");
function check(condition, label) {
  if (!condition) throw new Error(`FAIL: ${label}`);
  passed += 1;
  checks.push(label);
}

check(sha256(rcStandaloneBytes) === "5ef43eea301fd40e60002d68e978808128040c23959bc260cd8d19de79006868", "accepted R153.8 Standalone hash is immutable");
check(sha256(rcPlayerBytes) === "02b3e24e24cd7393a550aa47f1a07c3396c9327603645e1337197f4daa948b36", "accepted R153.8 Player hash is immutable");
check(standalone.includes("<title>Stackadia 1.4.1 Final</title>"), "Standalone title identifies Stackadia 1.4.1 Final");
check(standalone.includes('<meta content="1.4.1" name="stackadia-version"/>'), "Standalone version metadata identifies 1.4.1");
check(standalone.includes('developmentPhase: "Phase 6.18.9 / R153.9"'), "Standalone product identity identifies R153.9");
check(standalone.includes('sourceBaseline: "Accepted R153.8 RC1 Standalone · SHA-256 5ef43eea301fd40e60002d68e978808128040c23959bc260cd8d19de79006868"'), "Standalone freezes the accepted R153.8 parent");
check(standalone.includes('featureLockStatus: "Stackadia 1.4.1 Final Frozen"'), "Standalone declares the maintenance Final freeze");
check(standalone.includes('downloadBlob(blob, "Stackadia_1.4.1_Final_Lightweight_Player.html")'), "Standalone exports the correctly named Final Player");
check(!standalone.includes("Stackadia_1.3.2_Final_Lightweight_Player.html"), "obsolete Player export filename is absent");

check(player.includes("<title>Stackadia Lightweight Player — 1.4.1 Final</title>"), "Player title identifies Stackadia 1.4.1 Final");
check(player.includes('data-stackadia-player-runtime="R153.9"'), "Player runtime marker identifies R153.9");
check(player.includes('applicationVersion: "1.4.1"'), "Player product identity identifies 1.4.1 Final");
check(player.includes('sourceBaseline: "Accepted R153.8 RC1 Player · SHA-256 02b3e24e24cd7393a550aa47f1a07c3396c9327603645e1337197f4daa948b36"'), "Player freezes the accepted R153.8 parent");

const payloadMatch = standalone.match(/<script type="application\/octet-stream" data-stackadia-renewed-player([^>]*)>([^<]+)<\/script>/);
check(Boolean(payloadMatch), "Standalone contains the embedded Final Player");
const embeddedPlayer = gunzipSync(Buffer.from(payloadMatch[2].trim(), "base64")).toString("utf8");
check(embeddedPlayer === player, "external and embedded Final Player bytes are identical");
check(payloadMatch[1].includes('data-stackadia-payload-key="renewed-player-1.4.1-Final"'), "embedded Player payload key identifies Final");
check(payloadMatch[1].includes(`data-stackadia-sha256="${sha256(player)}"`), "embedded Player declares its exact SHA-256");
check(Number(payloadMatch[1].match(/data-stackadia-uncompressed-bytes="(\d+)"/)?.[1]) === Buffer.byteLength(player), "embedded Player declares its exact byte count");

const extractBlock = (text, start, end) => text.match(new RegExp(`${start}[\\s\\S]*?${end}`))?.[0];
const rcHelper = rcStandalone.match(/\n    applyAuthorDisplayRect\(object, targetRect, options = \{\}\) \{[\s\S]*?\n    \}(?=\n    objectGroupState\(object\))/)?.[0];
const finalHelper = standalone.match(/\n    applyAuthorDisplayRect\(object, targetRect, options = \{\}\) \{[\s\S]*?\n    \}(?=\n    objectGroupState\(object\))/)?.[0];
check(Boolean(finalHelper) && finalHelper === rcHelper, "responsive author-geometry correction is byte-identical to accepted R153.8");
check(standalone.includes("this.adjustDrag(dx, dy, this.interaction.initialDisplayRects)"), "Final retains displayed-geometry pointer dragging");
check(standalone.includes("x: displayed.x + dx, y: displayed.y + dy"), "Final retains responsive arrow-key nudging");
check(standalone.includes('initialRect: this.displayRect(object)'), "Final retains displayed-geometry resizing");

const speechService = (text) => extractBlock(text, "/\\* STACKADIA_SPEECH_HOST_SERVICE_BEGIN R153\\.2", "/\\* STACKADIA_SPEECH_HOST_SERVICE_END R153\\.2 \\*/");
check(speechService(standalone) === speechService(rcStandalone), "Standalone speech service is byte-identical to accepted R153.8");
check(sha256(speechService(standalone)) === "c1281a1d4773cf04510e5477fefc5987743c6eb9e1349605ee611b9a07965d56", "speech service retains its accepted hash");
check(speechService(player) === speechService(rcPlayer), "Player speech service is byte-identical to accepted R153.8");

const namedScript = (text, id) => text.match(new RegExp(`<script id="${id}"[^>]*>([\\s\\S]*?)<\\/script>`))?.[1];
check(namedScript(standalone, "stackadiaScriptLexical") === namedScript(rcStandalone, "stackadiaScriptLexical"), "Script lexical service is byte-identical to accepted R153.8");
check(namedScript(standalone, "stackadiaScriptRuntimeWorker") === namedScript(rcStandalone, "stackadiaScriptRuntimeWorker"), "Script runtime worker is byte-identical to accepted R153.8");
const styles = (text) => [...text.matchAll(/<style[^>]*>([\s\S]*?)<\/style>/g)].map((match) => match[1]);
check(JSON.stringify(styles(standalone)) === JSON.stringify(styles(rcStandalone)), "Standalone styles are byte-identical to accepted R153.8");
check(JSON.stringify(styles(player)) === JSON.stringify(styles(rcPlayer)), "Player styles are byte-identical to accepted R153.8");

const playerRuntime = (text) => text.match(/<script data-stackadia-player-runtime="R153\.[89]">([\s\S]*?)<\/script><\/body><\/html>/)?.[1];
const normalizePlayerRuntime = (text) => text
  ?.replace(/const PRODUCT_IDENTITY = Object\.freeze\(\{[\s\S]*?\n\}\);/, "const PRODUCT_IDENTITY = RELEASE_IDENTITY;")
  .replace(/'Stackadia Lightweight Player — 1\.4\.1(?: RC1| Final)'/g, "'Stackadia Lightweight Player — 1.4.1 RELEASE'")
  .replace(/revision:'R153\.[89]'/g, "revision:'R153.RELEASE'");
check(normalizePlayerRuntime(playerRuntime(player)) === normalizePlayerRuntime(playerRuntime(rcPlayer)), "Player executable runtime differs from accepted R153.8 only in Final identity markers");

check(sha256(demo) === sha256(rcDemo), "speech demonstration XStack is byte-identical to accepted R153.8");
check(guide.includes("Stackadia 1.4.1 Final") && guide.includes("R153.9"), "User Guide identifies the maintenance Final");
check(guide.includes("unlocked Buttons, Labels, and other objects can again be dragged, resized, and nudged"), "User Guide documents the responsive authoring correction");
check(dictionary.includes("Stackadia 1.4.1 Final") && dictionary.includes("R153.9"), "Script Dictionary identifies the maintenance Final");
check(dictionary.includes("Search 505 entries"), "Script Dictionary retains 505 entries");

for (const [name, document] of [["Standalone", standalone], ["Player", player]]) {
  const scripts = [...document.matchAll(/<script([^>]*)>([\s\S]*?)<\/script>/g)]
    .filter((match) => !/type="(?:application\/octet-stream|application\/json|text\/plain)"/.test(match[1]));
  scripts.forEach((match, index) => new vm.Script(match[2], { filename: `${name}-script-${index + 1}.js` }));
  check(scripts.length > 2, `${name} executable scripts pass syntax compilation`);
}

console.log(JSON.stringify({ passed, failed: 0, checks }, null, 2));
