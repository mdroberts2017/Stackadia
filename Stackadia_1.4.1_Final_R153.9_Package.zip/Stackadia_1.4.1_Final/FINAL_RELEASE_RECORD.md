# Stackadia 1.4.1 Final Release Record

## Canonical identity

- Product: Stackadia
- Version: 1.4.1 Final
- Phase: 6.18.9
- Revision: R153.9
- Milestone: Stackadia 1.4.1 Maintenance Final
- Release date: September 18, 2026

## Accepted parent

- Stackadia 1.4.1 RC1 / R153.8
- Standalone SHA-256: `5ef43eea301fd40e60002d68e978808128040c23959bc260cd8d19de79006868`
- Lightweight Player SHA-256: `02b3e24e24cd7393a550aa47f1a07c3396c9327603645e1337197f4daa948b36`
- RC package SHA-256: `4191a70f749448e31454dd8d5ad3babcf53c16e79a8d583c73f81f224b2be9ed`

The owner confirmed that every R153.8 hands-on maintenance check passed and authorized promotion to a maintenance Final.

## Final scope

Stackadia 1.4.1 corrects responsive Author-mode direct manipulation. Unlocked objects can be dragged, resized, nudged, aligned, distributed, and size-matched while their visible responsive constraints are updated correctly.

R153.9 changes production identity, documentation, release records, manifests, and package hashes. It introduces no application-behavior change after R153.8 acceptance. The responsive author-geometry correction, speech service, Script worker, styles, and demonstration XStack remain byte-identical to the accepted candidate.

The external Final Player and the Player embedded in Final Standalone are byte-identical. After normalization of Final identity markers, the Player executable runtime is identical to R153.8 RC1.

## Immutability

`Stackadia_1.4.1_Final_Standalone.html` and `Stackadia_1.4.1_Final_Lightweight_Player.html` are immutable production artifacts. Any later application-byte change requires a new maintenance or development identity and proportionate requalification.

## Frozen exclusions

Web App and PWA output remain frozen development references outside the Stackadia 1.4.1 Final production boundary.
