# Stackadia 1.4.4 Final XStack developer kit

Matched to Phase 6.21.16 / R156.16; schema48, Script1.2, XStack3. Read the contract and run `python3 xstack_validate.py --canonical HAO_Dev14_Authoring_Example_R156.14.xstack`.

The example, original HTML, exact reference manifest/project and independent validator retain their accepted Dev14 bytes and original export metadata. New Final host exports carry applicationVersion `1.4.4 Final` and releaseChannel `Final`. Reference JSON files are separate developer aids, not additional XStack members. The distribution kit is ordinary ZIP; enclosed XStacks use STORED members. The validator checks selected structural/integrity/map fields and supports historical layouts in default mode; it is not exhaustive native-object schema or code safety certification. Public bridge, optional capabilities and multi-file packaging remain future work.

Michael Roberts · 2026 · GPL-3.0-or-later · Contains AI-generated content. See supplied notices.
