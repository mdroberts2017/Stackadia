#!/usr/bin/env python3
"""Validate the documented XStack3 publication envelope, not app behavior.
Copyright (C) 2026 Michael Roberts; SPDX-License-Identifier: GPL-3.0-or-later
"""
import argparse,hashlib,json,re,sys,zipfile
from pathlib import PurePosixPath
class InvalidXStack(ValueError):pass
def require(ok,message):
 if not ok:raise InvalidXStack(message)
def unique_object(pairs):
 d={}
 for k,v in pairs:
  require(k not in d,'Duplicate JSON key: '+k);d[k]=v
 return d
def parse_json(data,name):
 try:return json.loads(data.decode('utf-8'),object_pairs_hook=unique_object,parse_constant=lambda value:(_ for _ in ()).throw(InvalidXStack('Nonfinite JSON number: '+value)))
 except (UnicodeError,json.JSONDecodeError)as e:raise InvalidXStack('Invalid UTF-8 JSON: '+name)from e
def safe_path(name):
 return isinstance(name,str)and bool(name)and not name.startswith('/')and '\\'not in name and ':'not in name and all(p not in ('','.', '..')for p in name.split('/'))
def owners_for(p):
 yield p
 for category in ['backgrounds','cards']:
  for owner in p.get(category,[]):
   yield owner
   yield from owner.get('objects',[])
 yield from p.get('groups',[])
 for component in p.get('components',[]):
  yield from component.get('groups',[])
  yield from component.get('objects',[])
def validate(path,canonical=False):
 with zipfile.ZipFile(path)as z:
  infos=z.infolist();names=[i.filename for i in infos];require(len(names)==len(set(names)),'Duplicate ZIP member path');require(all(safe_path(n)for n in names),'Unsafe or noncanonical member path')
  require(all(i.compress_type==zipfile.ZIP_STORED for i in infos),'Use ZIP STORED entries (method0), not DEFLATE');require(all(not(i.flag_bits&1)for i in infos),'Encrypted ZIP entries are unsupported');require(all(i.extract_version<45 for i in infos),'ZIP64 is outside this publication profile')
  require('manifest.json'in names,'Missing manifest.json');data={n:z.read(n)for n in names} # zipfile checks each CRC
  m=parse_json(data['manifest.json'],'manifest.json');require(isinstance(m,dict),'Manifest must be an object');require(m.get('format')=='Stackadia XStack Package'and m.get('packageVersion')==3,'Unsupported format/packageVersion');require(m.get('schemaVersion')in(47,48),'Validator publication profile supports schema47/48');require(m.get('languageVersion')=='1.2','Publication profile requires Script1.2')
  integrity=m.get('integrity',{});require(isinstance(integrity,dict)and integrity.get('algorithm')=='SHA-256','Expected SHA-256 integrity');hashes=integrity.get('files');require(isinstance(hashes,dict)and set(hashes)==set(names)-{'manifest.json'},'Integrity map must cover every member except manifest.json exactly')
  for n,h in hashes.items():require(isinstance(h,str)and re.fullmatch('[0-9a-f]{64}',h)and hashlib.sha256(data[n]).hexdigest()==h,'SHA-256 mismatch or invalid digest: '+n)
  project_path=m.get('projectPath');require(project_path in data and project_path!='manifest.json','Missing/invalid projectPath');p=parse_json(data[project_path],project_path);require(isinstance(p,dict),'Project must be an object');require(p.get('schemaVersion')==m['schemaVersion']and p.get('languageVersion')==m['languageVersion'],'Manifest/project version mismatch');require(p.get('id')==m.get('projectId')and p.get('title')==m.get('title'),'Manifest/project identity mismatch')
  for key in ['cards','backgrounds','assets','groups','components']:require(isinstance(p.get(key),list),'Project missing array: '+key)
  require(p['cards']and p['currentCardId']in{c['id']for c in p['cards']},'Invalid currentCardId');require(p.get('runtimeGlobals')=={}and p.get('runtimeScriptLocals')=={},'Package must clear session script state')
  owners=list(owners_for(p));ids=[o.get('id')for o in owners];require(all(isinstance(i,str)and i for i in ids)and len(ids)==len(set(ids)),'Owner IDs must be unique nonempty strings');known={o['id']:o for o in owners}
  scripts=m.get('scripts');assets=m.get('assets');require(isinstance(scripts,dict)and isinstance(assets,dict),'Missing scripts/assets maps');require(set(scripts)<=set(known),'Script owner does not exist');require(len(set(scripts.values()))==len(scripts),'Script paths must be unique')
  warnings=[]
  for owner in owners:
   if owner.get('script',''):
    if canonical:require(False,'Canonical packaged owner.script must be empty')
    warnings.append('Inline script ignored by loader for owner '+owner['id']+'; manifest.scripts is authoritative')
  for id,n in scripts.items():
   require(safe_path(n)and n in data and (not canonical or(n.startswith('scripts/')and n.endswith('.bcscript'))),'Invalid/missing script path: '+str(n));require(data[n]!=b'','Empty scripts should be omitted');data[n].decode('utf-8')
  asset_ids=[a.get('id')for a in p['assets']];require(len(asset_ids)==len(set(asset_ids))and all(isinstance(i,str)and i for i in asset_ids),'Asset IDs must be unique strings');require(set(assets)==set(asset_ids),'Asset map must match project assets exactly');require(len(set(assets.values()))==len(assets),'Asset paths must be unique')
  byasset={a['id']:a for a in p['assets']}
  for a in p['assets']:
   n=assets[a['id']];require(safe_path(n)and n.startswith('assets/')and n in data and a.get('packagePath')==n,'Asset path/map mismatch');require(a.get('dataUrl')=='','Packaged asset.dataUrl must be empty');require(isinstance(a.get('mimeType'),str),'Asset MIME type missing')
   if a.get('kind')=='htmlapp':require(a['mimeType']=='text/html'and n.endswith(('.html','.htm')),'Canonical HTML asset kind/MIME/path mismatch');data[n].decode('utf-8-sig')
  objects=[o for c in p['cards']+p['backgrounds']for o in c.get('objects',[])]+[o for c in p['components']for o in c.get('objects',[])]
  for o in objects:
   if o.get('type')!='htmlApp':continue
   require(p['schemaVersion']==48,'HTML App requires schema48');props=o.get('properties',{});aid=props.get('htmlAppAssetId')or props.get('assetId');require(aid in byasset and byasset[aid].get('kind')=='htmlapp','HTML App must reference a packaged htmlapp asset');require(props.get('htmlAppCapabilityMode','isolated')=='isolated','This profile exposes only isolated HAO');require(props.get('htmlAppViewportMode','responsive')in('responsive','native','contain'),'Unknown HTML viewport mode')
  require(len(set([project_path,*scripts.values(),*assets.values()]))==1+len(scripts)+len(assets),'Mapped resource paths overlap')
  return {'file':str(path),'packageVersion':3,'schemaVersion':p['schemaVersion'],'languageVersion':'1.2','members':len(names),'assets':len(assets),'scripts':len(scripts),'htmlApps':sum(o.get('type')=='htmlApp'for o in objects),'canonicalProfile':canonical,'warnings':warnings,'sha256':hashlib.sha256(open(path,'rb').read()).hexdigest()}
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--canonical',action='store_true',help='Require current exporter script layout and cleared inline scripts');ap.add_argument('files',nargs='+');args=ap.parse_args();failed=False
 for path in args.files:
  try:print(json.dumps({'status':'PASS',**validate(path,args.canonical)},ensure_ascii=False))
  except (ValueError,KeyError,TypeError,AttributeError,IndexError,UnicodeError,OSError,zipfile.BadZipFile,NotImplementedError,RuntimeError)as e:failed=True;print(json.dumps({'status':'FAIL','file':path,'error':str(e)}))
 return 1 if failed else 0
if __name__=='__main__':sys.exit(main())
