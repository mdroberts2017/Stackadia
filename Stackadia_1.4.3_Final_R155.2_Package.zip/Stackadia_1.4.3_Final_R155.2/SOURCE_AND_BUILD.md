# Source and build

The self-contained Final HTML applications are distributed source. LICENSE.txt preserves the complete GNU GPL version 3. THIRD_PARTY_NOTICES.txt preserves the complete Three.js MIT license. DISCLAIMER.txt and AI_CONTENT_NOTICE.txt are distribution notices.

source/promote_r1552.py derives Final from the accepted R155.1 RC1 with guarded input hashes, allowlisted identity substitutions, deterministic exact-Player embedding, normalized-equivalence assertions, and integrity checks. The script refuses to overwrite its output directory. No external network dependency is introduced.
