# Stackadia 1.4.3 Final User Guide supplement

## Legal notices

In Stackadia, choose About Stackadia and select **Legal Notices…**. In the Lightweight Player, select **About**. Both surfaces provide License, Disclaimer, Third-Party Materials, and AI Content information. The full GPL, disclaimer, Third-Party Notices, and AI notice also accompany the package.

Distributions generated with the Stackadia runtime must retain the applicable GPL information, warranty disclaimer, third-party notice, AI-content statement, and corresponding source obligations.
