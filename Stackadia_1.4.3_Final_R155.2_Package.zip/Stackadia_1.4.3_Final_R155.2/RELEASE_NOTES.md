# Stackadia 1.4.3 Final — release notes

Phase 6.20.2 / R155.2. Promoted from accepted Stackadia 1.4.3 RC1 / Phase 6.20.1 / R155.1 after the owner reported that everything looked good and authorized Final promotion.

The release adds the complete Stackadia warranty/liability disclaimer, verified Three.js attribution and complete MIT license, the exact statement “Contains AI-generated content.”, and clear License, Disclaimer, Third-Party Materials, and AI Content sections in both applications.

R155.2 changes Final identity, documentation, checksums, and the embedded Final Player payload only. There are no additional feature, schema, scripting-language, runtime, interface-architecture, or compatibility changes.
