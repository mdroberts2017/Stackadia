# Final release record

**Stackadia 1.4.3 Final / Phase 6.20.2 / R155.2**

Owner acceptance: “Everything looks good. Please promote to Final.”

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| Stackadia_1.4.3_Final_Standalone.html | 8321010 | b61abcf242f5db85abb2e8c6725a3e4bf108f3b69a5217eff3848857c5add3db |
| Stackadia_1.4.3_Final_Lightweight_Player.html | 3707694 | 061d7174c4e546643b82d3afec26af5b3e6c7d4aad7c0cc61cf1bee09b1c726a |

The accepted R155.1 RC1 and prior R154.3 Final remain immutable historical baselines. R155.2 is a promotion-only Final identity and packaging revision.
