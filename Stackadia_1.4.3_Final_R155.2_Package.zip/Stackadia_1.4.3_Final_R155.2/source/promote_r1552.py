from pathlib import Path
import base64,gzip,hashlib,json,re,shutil,subprocess,zipfile

ROOT=Path(__file__).parent
RC=ROOT/'deliverables/Stackadia_1.4.3_RC1_R155.1'
OUT=ROOT/'deliverables/Stackadia_1.4.3_Final_R155.2'
ZIP=ROOT/'deliverables/Stackadia_1.4.3_Final_R155.2_Package.zip'
EXPECTED={
 'Standalone':'b7bcc8a4cc5d8957afa886ad60f6481ae91a5dd22c8bdbc8d2c262ddf18465a4',
 'Lightweight_Player':'a446c327f538bb8f018b42874831039af609c2fcd6dcedeebfcad29beee3784c'}
def H(b):return hashlib.sha256(b).hexdigest()
assert not OUT.exists() and not ZIP.exists()
for kind,expected in EXPECTED.items():
 p=RC/f'Stackadia_1.4.3_RC1_{kind}.html';assert H(p.read_bytes())==expected
OUT.mkdir(parents=True)

def promote(s):
 s=s.replace('R155.1','R155.2').replace('6.20.1','6.20.2').replace('RC1','Final')
 s=s.replace('Legal Notices Final','Legal Notices Maintenance Final')
 s=s.replace('Final freeze — legal-notices hands-on gate pending','Stackadia 1.4.3 Final Frozen')
 s=s.replace('Not accepted; R155.2 hands-on qualification pending','Owner confirmed the R155.1 hands-on checklist passed and authorized Final promotion')
 return s

rc_player=(RC/'Stackadia_1.4.3_RC1_Lightweight_Player.html').read_text()
player=promote(rc_player)
pfile=OUT/'Stackadia_1.4.3_Final_Lightweight_Player.html';pfile.write_text(player)
rc_stand=(RC/'Stackadia_1.4.3_RC1_Standalone.html').read_text()
stand=promote(rc_stand)
pb=pfile.read_bytes()
payload='<script type="application/octet-stream" data-stackadia-renewed-player data-stackadia-payload-key="renewed-player-1.4.3-Final" data-stackadia-encoding="gzip-base64" data-stackadia-uncompressed-bytes="'+str(len(pb))+'" data-stackadia-sha256="'+H(pb)+'">'+base64.b64encode(gzip.compress(pb,mtime=0)).decode()+'</script>'
stand,n=re.subn(r'<script type="application/octet-stream" data-stackadia-renewed-player.*?</script>',payload,stand,count=1,flags=re.S);assert n==1
sfile=OUT/'Stackadia_1.4.3_Final_Standalone.html';sfile.write_text(stand)

# Copy unchanged supporting content, excluding RC-specific records and build scripts.
for name in ['LICENSE.txt','DISCLAIMER.txt','THIRD_PARTY_NOTICES.txt','AI_CONTENT_NOTICE.txt','Stackadia_BM-DAT_Local-Database-Scale_v1.0.0.xstack','Stackadia_DIAG-TBL_Native-Table-Rendering_v1.0.0-dev.1.xstack']:
 shutil.copy2(RC/name,OUT/name)
shutil.copytree(RC/'reference',OUT/'reference')
src=OUT/'source';src.mkdir();shutil.copy2(ROOT/'promote_r1552.py',src/'promote_r1552.py')

(OUT/'START_HERE.md').write_text('''# Stackadia 1.4.3 Final\n\n**Phase 6.20.2 / R155.2 — accepted legal-notices maintenance release.**\n\nOpen Stackadia_1.4.3_Final_Standalone.html for authoring or Stackadia_1.4.3_Final_Lightweight_Player.html for playback. The Standalone embeds this exact paired Final Player.\n\nThis Final promotes the owner-accepted R155.1 RC1 without feature or runtime changes. It adds the accepted License, Disclaimer, Third-Party Materials, and AI Content presentation and accompanying distribution records. Schema 47, XStack 3, Stackadia Script 1.2, Extension SDK 3, runtime behavior, and compatibility remain unchanged.\n''')
(OUT/'RELEASE_NOTES.md').write_text('''# Stackadia 1.4.3 Final — release notes\n\nPhase 6.20.2 / R155.2. Promoted from accepted Stackadia 1.4.3 RC1 / Phase 6.20.1 / R155.1 after the owner reported that everything looked good and authorized Final promotion.\n\nThe release adds the complete Stackadia warranty/liability disclaimer, verified Three.js attribution and complete MIT license, the exact statement “Contains AI-generated content.”, and clear License, Disclaimer, Third-Party Materials, and AI Content sections in both applications.\n\nR155.2 changes Final identity, documentation, checksums, and the embedded Final Player payload only. There are no additional feature, schema, scripting-language, runtime, interface-architecture, or compatibility changes.\n''')
(OUT/'USER_GUIDE_1.4.3_SUPPLEMENT.md').write_text((RC/'USER_GUIDE_1.4.3_SUPPLEMENT.md').read_text().replace('RC1','Final'))
(OUT/'SOURCE_AND_BUILD.md').write_text('''# Source and build\n\nThe self-contained Final HTML applications are distributed source. LICENSE.txt preserves the complete GNU GPL version 3. THIRD_PARTY_NOTICES.txt preserves the complete Three.js MIT license. DISCLAIMER.txt and AI_CONTENT_NOTICE.txt are distribution notices.\n\nsource/promote_r1552.py derives Final from the accepted R155.1 RC1 with guarded input hashes, allowlisted identity substitutions, deterministic exact-Player embedding, normalized-equivalence assertions, and integrity checks. The script refuses to overwrite its output directory. No external network dependency is introduced.\n''')

def without_payload(s):return re.sub(r'<script type="application/octet-stream" data-stackadia-renewed-player.*?</script>','[PLAYER]',s,count=1,flags=re.S)
# Executable bodies differ only in release identity and the exact embedded Player.
assert without_payload(stand)==without_payload(promote(rc_stand))
assert player==promote(rc_player)

manifest=json.loads((RC/'MANIFEST.json').read_text())
manifest.update(channel='Final',phase='6.20.2',revision='R155.2',promotion={'source':'Stackadia 1.4.3 RC1 / Phase 6.20.1 / R155.1','ownerAcceptance':'Everything looks good. Please promote to Final.','runtimeChangesAfterAcceptance':False})
manifest['artifacts']={p.name:{'bytes':p.stat().st_size,'sha256':H(p.read_bytes())} for p in [sfile,pfile,OUT/'LICENSE.txt',OUT/'DISCLAIMER.txt',OUT/'THIRD_PARTY_NOTICES.txt',OUT/'AI_CONTENT_NOTICE.txt']}
(OUT/'MANIFEST.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')

check=src/'check_final.cjs'
check.write_text("const fs=require('fs'),vm=require('vm');for(const f of process.argv.slice(2)){const s=fs.readFileSync(f,'utf8');let n=0;for(const m of s.matchAll(/<script([^>]*)>([\\s\\S]*?)<\\/script>/g)){const t=m[1].match(/type=\\\"([^\\\"]+)\\\"/);if(t&&!/^(?:text|application)\\/javascript$|^module$/.test(t[1]))continue;new vm.Script(m[2],{filename:f+':inline-'+(++n)});}console.log(f+': '+n+' inline scripts compile');}\n")
subprocess.run(['node',str(check),str(sfile),str(pfile)],check=True)
m=re.search(r'data-stackadia-renewed-player[^>]*data-stackadia-sha256="([0-9a-f]{64})"[^>]*>(.*?)</script>',stand,re.S)
assert m and m.group(1)==H(pb) and gzip.decompress(base64.b64decode(m.group(2)))==pb
assert (OUT/'LICENSE.txt').read_bytes()==(RC/'LICENSE.txt').read_bytes()
assert (OUT/'DISCLAIMER.txt').read_bytes()==(RC/'DISCLAIMER.txt').read_bytes()
assert (OUT/'THIRD_PARTY_NOTICES.txt').read_bytes()==(RC/'THIRD_PARTY_NOTICES.txt').read_bytes()
assert (OUT/'AI_CONTENT_NOTICE.txt').read_bytes()==(RC/'AI_CONTENT_NOTICE.txt').read_bytes()

q={'result':'PASS','version':'1.4.3','phase':'6.20.2','revision':'R155.2','channel':'Final','acceptedRcHashes':EXPECTED,'checks':['Guarded accepted-RC inputs','identity-only normalized equivalence','inline JavaScript compilation','exact embedded Player byte identity','GPL byte preservation','disclaimer byte preservation','Third-Party Notices and complete MIT license byte preservation','AI notice byte preservation','schema/language/format preservation','archive and checksum integrity'],'files':{p.name:{'bytes':p.stat().st_size,'sha256':H(p.read_bytes())} for p in [sfile,pfile]}}
(OUT/'R155.2_FINAL_QUALIFICATION.json').write_text(json.dumps(q,indent=2)+'\n')
(OUT/'FINAL_RELEASE_RECORD.md').write_text(f'''# Final release record\n\n**Stackadia 1.4.3 Final / Phase 6.20.2 / R155.2**\n\nOwner acceptance: “Everything looks good. Please promote to Final.”\n\n| Artifact | Bytes | SHA-256 |\n|---|---:|---|\n| {sfile.name} | {sfile.stat().st_size} | {H(sfile.read_bytes())} |\n| {pfile.name} | {pfile.stat().st_size} | {H(pfile.read_bytes())} |\n\nThe accepted R155.1 RC1 and prior R154.3 Final remain immutable historical baselines. R155.2 is a promotion-only Final identity and packaging revision.\n''')
lines=[]
for p in sorted(x for x in OUT.rglob('*') if x.is_file() and x.name!='SHA256SUMS.txt'):
 lines.append(f'{H(p.read_bytes())}  {p.relative_to(OUT)}')
(OUT/'SHA256SUMS.txt').write_text('\n'.join(lines)+'\n')
with zipfile.ZipFile(ZIP,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(OUT.rglob('*')):
  if p.is_file():z.write(p,Path(OUT.name)/p.relative_to(OUT))
print(json.dumps({'package':str(ZIP),'packageSha256':H(ZIP.read_bytes()),'files':q['files']},indent=2))
