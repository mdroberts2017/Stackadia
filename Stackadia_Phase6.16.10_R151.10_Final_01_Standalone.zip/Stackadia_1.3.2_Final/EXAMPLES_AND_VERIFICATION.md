# Examples and Optional Verification

The owner has accepted testing and authorized Final promotion. These examples are for exploration or troubleshooting; another owner acceptance checklist is not required.

Start with `examples/SC-02_Interactive_Story.xstack`. Enter text, create the story, return and change the input. The baseline folder contains control, geometry, timer, gradient, media and Scene3D conformance examples. `examples/R141.5_Pachinko_Schema44_Acceptance.xstack` demonstrates Animation Stage simulation; Clear stops the active balls.

For signed libraries, open `examples/R151.6.1_Signed_SDK2_3.xstack`. In Standalone, Test, Approve Selected and Enable both extensions. In Player, approve when opening. The expected outputs are:

| Button | Result |
|---|---|
| SDK2 Status | ready |
| SDK3 Uppercase | HELLO STACKADIA |
| SDK3 Sum | 6 |
| SDK3 Type Guard | PASS — invalid input rejected |

Save/reopen and approve again as appropriate to check an external project copy. Player Home closes playback; Standalone File → Close Project closes the current project.

Files named Expected_Failure are deliberate negative cases. Invalid/future-schema packages should be visibly rejected. Player should reject an invalid required extension and keep a previously open valid stack usable. Standalone may open the tampered-extension example for inspection with its extension disabled; Test must reject it. A silent hang is not an expected pass.

For a future maintenance report, include the exact Final filename/hash, OS/browser, XStack, reproduction steps, expected and actual results, and whether the other application differs. Remove private credentials and confidential content from shared examples. A reported problem should be investigated in the platform, without changing a user's stack merely to hide it.
