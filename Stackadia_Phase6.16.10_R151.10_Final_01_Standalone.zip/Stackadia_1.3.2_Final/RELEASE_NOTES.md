# Stackadia 1.3.2 Final — Release Notes

## Paired authoring and playback

The renewed Lightweight Player accompanies the Standalone authoring application. It uses the accepted playback core for cards, navigation, Script, controls, data, media, Scene3D and Animation Stage behavior within the documented qualification scope. Export Player supplies the same universal Player as the separate download; export or save the XStack separately.

## Changes carried from the accepted renewal cycle

- Reconciled Standalone/Player navigation and lifecycle behavior, including the retained declarative-navigation correction.
- Corrected Project Browser floating, movement and Dock Right behavior; retained Smart Objects layout and scrolling corrections.
- Corrected signed-extension provenance and normal verification paths. Bundled SDK2 and SDK3 examples use genuine scoped signatures and the current worker protocol.
- Kept verification, approval and enablement separate. Imported extensions in Standalone can regain verified status through a successful package Test, followed by approval and enabling.
- Terminated extension workers when resetting/closing a project session.
- Updated the in-app and offline Guide/Dictionary for the paired applications, project resizing, windows, extension workflows, save/reopen and the frozen Web boundary.

## Final promotion

No RC2 correction was identified by the owner after testing. Final changes only release identity and corresponding labels; it adds no runtime feature or behavioral fix over the accepted RC1. The source audit and promotion checks are included with the corresponding-source materials.

## Working with signed stacks

On Standalone import, use Extensions → Test → Approve Selected → Enable for each required sample. Player verifies required packages on open and requests approval. A signature does not grant device or project permission. Invalid required providers block Player playback; Standalone can inspect a project while its unverified extensions remain disabled.

## Compatibility boundaries

Local packaged resources can run offline. Remote URLs, services and device access still depend on their availability and permissions. Authoring remains a Standalone function. The release does not certify every third-party extension or device. Tablets require separate qualification; phones are excluded. Web/PWA remains frozen. Current formats are schema 47, XStack 3 and Script 1.2.
