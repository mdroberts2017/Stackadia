# Stackadia 1.3.2 Final

**Phase 6.16.10 / R151.10 — Stackadia 1.3.2 Final Promotion & Release Closure**

Stackadia 1.3.2 is promoted to Final following the owner's report that testing passed, no RC2 corrections were identified, and Final promotion was requested. The release includes the full Standalone, corresponding Lightweight Player, matching User Guide and Script Dictionary. Phase 6.16 Lightweight Player renewal is closed.

## Open the release

- `Stackadia_1.3.2_Final_Standalone.html` — create, edit and run XStacks.
- `Stackadia_1.3.2_Final_Lightweight_Player.html` — open and play XStacks without the authoring workspace.
- `Stackadia_1.3.2_Final_User_Guide.html` — complete searchable offline Guide.
- `Stackadia_1.3.2_Final_Script_Dictionary.html` — complete searchable offline Dictionary.

Open an HTML file in your desktop browser. The Player is a universal launcher: choose the XStack separately. Standalone Export Player produces the byte-identical Final Player supplied in this release. Save your projects as external XStack files; browser-local recovery is not your only backup.

## Downloads

All six independent ZIPs merge into `Stackadia_1.3.2_Final/`. Packages 01–03 contain the applications, references and example/test stacks. Packages 04–06 contain the build source, evidence and exact accepted RC1 source inputs. Keep the license and third-party notices with the distribution. Source instructions are in `source/R151.10/Reproduction.md`.

Each archive is below 3.5 MB. `SHA256SUMS.txt` identifies the downloads and canonical core files. `Final_Manifest.json` records the immutable Final hashes.

## Promotion scope

Application version: **1.3.2**. Release channel: **Final**. Project schema: **47**. XStack format: **3**. Stackadia Script: **1.2**. Extension SDK: **3**, including retained SDK1/2 support.

This is an identity-only promotion of the tested RC1 behavior. Application metadata, release labels, filenames and matching reference headings now identify Final. Those edits change the file hashes; this is not a claim that Final HTML bytes equal RC1 bytes. A source audit verifies that runtime behavior is unchanged. All 503 Dictionary entries and 17 retained embedded modules, including the frozen Web payloads, remain unchanged. The complete Guide retains 27 topics.

RC1 and older production releases, including 1.3.1 Final, remain immutable historical files. The new canonical production pair is 1.3.2 Final. Any later correction requires a new maintenance revision; do not overwrite these Final files with changed content.

## Qualification and scope

The accepted RC1 testing is the functional baseline. Final promotion checks cover source preservation, startup/release identities, references, documented SDK2/3 execution, rejection, save/reopen, worker cleanup, Player host behavior and exact Player export. See `Final_Qualification.json` and archived evidence. This is not a new execution of every historical regression or a new certification of all third-party extensions and devices.

Desktop macOS is the primary qualified environment. The last owner-supplied environment was macOS 26.6.2 with Chrome 153.0.8010.36 arm64. Automated browser evidence is Linux Chromium 153.0.8010.0. Tablet results remain separate, and phones are excluded. Network services and device permissions retain their documented limits. Web/PWA remains frozen and is not promoted as a new Final target.

No additional owner checklist is required for this identity-only promotion. No files were published to a host or sent to third parties by the assistant. Future feedback can be handled on a new maintenance branch while preserving this release.
