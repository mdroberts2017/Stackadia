# Changelog

## R152.1 — 2026-09-14

- First public draft of XStack Package Format 3.
- Documents the Stackadia 1.3.2 Final / project schema 47 profile.
- Adds JSON Schemas, a dependency-free CLI, and positive and negative conformance fixtures.
- Defines archive safety, integrity, script/asset externalization, and imported-extension trust behavior.

