# XStack Package Format 3 — Public Draft

This is the interoperability package for Stackadia 1.3.2 Final. It documents XStack package version 3 and the project schema 47 profile, and includes schemas, a dependency-free reference CLI, and conformance fixtures.

The specification is a Public Draft. It does not change the Stackadia 1.3.2 Final applications or the frozen Web/PWA build.

## Quick start

Requires Node.js 20 or newer.

```sh
node tools/xstack.cjs validate conformance/valid/minimal-schema47.xstack
node tools/xstack.cjs inspect conformance/valid/minimal-schema47.xstack
node tools/xstack.cjs unpack example.xstack output-directory
node tools/xstack.cjs pack input-directory example.xstack
node tests/run-conformance.cjs
```

The CLI uses only Node.js built-ins. `pack` writes the ZIP Store method used by Stackadia, rebuilds the SHA-256 integrity table, and validates the output.

## Contents

- `docs/`: human-readable specification in Markdown and HTML
- `schemas/`: JSON Schema 2020-12 definitions
- `tools/`: reference validator, inspector, unpacker, and packer
- `conformance/`: valid and deliberately invalid fixture packages
- `tests/`: reproducible conformance runner
- `evidence/`: qualification results and artifact inventory

## Status and licensing

The specification text is licensed under CC BY 4.0. Schemas, tools, and conformance material are licensed under MIT. See the license files. “Stackadia” and “XStack” are product and format identifiers; the licenses do not grant trademark rights.

