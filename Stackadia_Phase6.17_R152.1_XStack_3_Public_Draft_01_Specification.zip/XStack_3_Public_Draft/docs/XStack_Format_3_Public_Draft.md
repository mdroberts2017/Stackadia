---
title: XStack Package Format 3
subtitle: Stackadia 1.3.2 / Project Schema 47 Profile — Public Draft
date: 2026-09-14
---

# Status

This document is a Public Draft intended to make Stackadia projects independently readable, inspectable, preservable, and convertible. It specifies the package emitted and consumed by Stackadia 1.3.2 Final. It is not a promise that every internal authoring preference will remain unchanged in future project schemas.

The key words **MUST**, **MUST NOT**, **REQUIRED**, **SHOULD**, **SHOULD NOT**, and **MAY** are to be interpreted as described by RFC 2119 and RFC 8174 when they appear in capitals.

# Format identity

| Item | Value |
|---|---|
| File suffix | `.xstack` |
| Media type | `application/vnd.stackadia.xstack+zip` |
| Package format | `Stackadia XStack Package` |
| Package version | `3` |
| Current project schema | `47` |
| Stackadia Script version | `1.2` |
| Reference application | Stackadia 1.3.2 Final |

An XStack is a ZIP archive whose entries use the ZIP **Store** method (compression method 0). Stackadia 1.3.2 does not accept compressed entries. Entry names are UTF-8, use `/` as the separator, and are relative paths.

# Archive requirements

Conforming packages:

1. MUST contain exactly one `manifest.json` entry.
2. MUST use compression method 0 for every entry.
3. MUST use relative, forward-slash paths. Empty segments, `.`, `..`, absolute paths, drive-letter paths, NUL characters, and backslashes are forbidden.
4. MUST NOT contain duplicate entry names.
5. MUST pass the ZIP CRC-32 check for every entry.
6. SHOULD place `manifest.json` last, matching Stackadia output. Readers MUST NOT depend on entry order.
7. MUST contain every file listed by `manifest.integrity.files`, and every non-manifest file MUST be listed there.

These safety requirements are stricter than the original in-application ZIP reader where necessary to prevent ambiguous or unsafe extraction by independent tools.

# Package layout

```text
manifest.json
project/project.json
scripts/project/<project-id>.bcscript
scripts/backgrounds/<background-id>.bcscript
scripts/cards/<card-id>.bcscript
scripts/groups/<group-id>.bcscript
scripts/objects/<object-id>.bcscript
scripts/components/<component-id>/groups/<group-id>.bcscript
scripts/components/<component-id>/objects/<object-id>.bcscript
assets/<asset-id>.<extension>
```

Only `manifest.json` and the project document at `manifest.projectPath` are mandatory. Script and asset entries exist when the project has corresponding content.

# Manifest

`manifest.json` is UTF-8 JSON. Its normative structure is defined by `schemas/manifest-v3.schema.json`.

| Member | Type | Meaning |
|---|---:|---|
| `format` | string | MUST be `Stackadia XStack Package`. |
| `packageVersion` | integer | MUST be `3`. |
| `schemaVersion` | integer | Project schema stored in the package; `47` for this profile. |
| `languageVersion` | string | Stackadia Script language version, `1.2` for this profile. |
| `applicationVersion` | string | Application version that wrote the package. |
| `releaseChannel` | string | Release channel of the writer, such as `Final`. |
| `projectId` | string | Stable project identifier; MUST equal the project document `id`. |
| `title` | string | Display title; MUST equal the project document `title`. |
| `exportedAt` | string | RFC 3339 date-time of export. |
| `projectPath` | string | Path of the project JSON, normally `project/project.json`. |
| `scripts` | object | Owner ID to script-entry path map. |
| `assets` | object | Asset ID to asset-entry path map. |
| `integrity` | object | Algorithm and path-to-digest map. |

`integrity.algorithm` MUST be `SHA-256`. Digests are 64 lowercase hexadecimal characters computed over the exact stored entry bytes. `manifest.json` is intentionally not self-hashed.

# Project document

The project document is UTF-8 JSON. `schemas/project-schema-47.schema.json` defines the portable structural core. The schema deliberately permits extension members in extensible records so implementations can preserve data they do not understand.

The project root contains identity, canvas dimensions, cards, backgrounds, objects, groups, components, assets, themes, data, dependencies, extensions, localization, authoring settings, and release metadata. The required interoperable core is:

- `schemaVersion`, `languageVersion`, `id`, `title`
- `cardWidth`, `cardHeight`, `currentCardId`
- `cards`, `backgrounds`, `groups`, `components`, `assets`
- `script`, `runtimeGlobals`, `runtimeScriptLocals`

Each card and background owns an ordered `objects` array. Object drawing and hit-testing order is represented by `zIndex`; implementations SHOULD preserve array order as well. Rectangles contain numeric `x`, `y`, `width`, and `height` values. Object `type` is an open string: unknown types MUST be preserved even if a reader cannot render them.

Known Stackadia 1.3.2 object types include `accordion`, `animationSurface`, `audio`, `button`, `checkbox`, `date`, `ellipse`, `extension`, `field`, `graphic`, `image`, `label`, `list`, `popup`, `progress`, `radio`, `rect`, `scene3d`, `scrollbar`, `search`, `slider`, `stepper`, `table`, `tabs`, and `time`.

# Externalized scripts

When packaging, Stackadia moves non-empty scripts out of the project JSON. The corresponding `script` member in `project/project.json` is an empty string, and `manifest.scripts[ownerId]` names the `.bcscript` entry.

Script owners are the project, backgrounds, cards, top-level groups, and component groups and objects. Card/background objects share `scripts/objects/`. Owner IDs therefore MUST be unique among script-owning entities. A reader reconstructs an owner's script from the manifest map; absence means the empty script.

Implementations MUST treat script files as UTF-8 text and MUST NOT execute scripts merely to inspect or validate a package.

# Externalized assets

Each packaged asset is stored separately. In the project JSON, `dataUrl` is empty and `packagePath` names the archive entry. `manifest.assets[asset.id]` is authoritative, with `asset.packagePath` as a compatibility fallback.

The extension is chosen from the MIME type when known (`png`, `jpg`, `webp`, `gif`, `svg`, `mp3`, `wav`, `ogg`, `mp4`, `webm`) or from a sanitized filename extension, otherwise `bin`. Readers MUST use `mimeType`, not the suffix alone, when reconstructing an in-memory data URL.

# Cross-reference rules

A schema-47 package is semantically conforming when all of the following hold:

- manifest and project identity, title, and schema version agree;
- `currentCardId` identifies a card;
- every card `backgroundId` identifies a background;
- IDs are non-empty and unique within each entity collection;
- every script map path exists and is listed in integrity;
- every asset has a mapped file that exists and is listed in integrity;
- every non-manifest archive entry appears in integrity and no integrity path is absent;
- the project JSON's externalized `script` and asset `dataUrl` fields are empty.

Implementations MAY accept a broader set for recovery, but MUST distinguish recovery from conformance.

# Security and trust

An XStack package is data, not an installation authority. Integrity hashes detect accidental change or package inconsistency; they do not establish publisher identity.

On import, Stackadia 1.3.2 clears runtime globals and script locals. It also revokes imported extension trust: third-party provider grants return to prompt, service-binding approved capabilities are cleared, and extensions become disabled, unapproved, and signature-unverified. Users must reinstall or reverify signed extension packages and explicitly approve requested capabilities. Independent runtimes SHOULD apply an equivalent trust reset.

Validators and unpackers MUST reject unsafe paths and duplicates before writing files. They SHOULD impose reasonable archive size, entry count, JSON depth, and asset limits for their environment. Inspection MUST NOT execute scripts, load remote resources, or activate extensions.

# Compatibility and evolution

Package version and project schema are independent:

- `packageVersion` describes archive mechanics.
- `schemaVersion` describes the project data model.

Stackadia 1.3.2 opens project schemas 43 through 47 and saves schema 47. This publication specifies only the schema-47 profile. A tool MUST reject an unsupported future schema by default. Migration tools SHOULD operate on a copy, preserve the original package, report the source and target schemas, and never silently discard unknown members.

Future compatible additions may add optional members to extensible records without changing package version. A breaking archive-mechanics change requires a new package version. A breaking or meaningfully migrated project-model change requires a new project schema version.

# Conformance classes

| Class | Requirements |
|---|---|
| Archive reader | Parses Store-method ZIPs; checks CRC, names, duplicates, and bounds. |
| Structural validator | Archive reader plus manifest and schema validation. |
| Semantic validator | Structural validator plus integrity and cross-reference rules. |
| Preserving reader/writer | Semantic validator plus lossless preservation of unknown members and payload bytes. |
| Runtime | Preserving reader/writer plus documented rendering and script behavior. |

The included CLI is a semantic validator and a preserving archive reader/writer. It is not a Stackadia runtime.

# Public-draft stabilization criteria

The draft is ready to become a stable 3.0 specification after:

1. an independently implemented parser or converter passes the conformance kit;
2. at least one round trip preserves all entries of a representative schema-47 package;
3. reported ambiguities are resolved without changing accepted Stackadia 1.3.2 Final files; and
4. stable publication URLs and a change-control record are established.

# Licenses and attribution

This specification text is available under CC BY 4.0. The schemas, CLI, and conformance material are available under MIT. Attribution should name “XStack Package Format 3 — Stackadia 1.3.2 Profile.” These licenses do not grant trademark rights.

