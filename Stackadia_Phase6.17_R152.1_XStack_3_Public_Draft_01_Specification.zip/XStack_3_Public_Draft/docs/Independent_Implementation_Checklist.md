# Independent Implementation Checklist

An implementation can be recorded as independently conforming when its author can answer yes to all applicable items.

## Reader and validator

- Rejects non-ZIP, truncated, multi-disk, compressed, duplicate-name, and unsafe-path archives.
- Checks CRC-32 and the complete SHA-256 integrity map.
- Parses manifest and project JSON without executing scripts.
- Rejects unsupported package versions and future project schemas by default.
- Checks identity, cards/backgrounds, scripts, and assets across files.
- Preserves unknown project members when rewriting.

## Writer

- Writes UTF-8 names and Store-method entries.
- Externalizes scripts and assets according to the manifest maps.
- Covers every non-manifest entry with SHA-256.
- Writes a schema-47 project with empty runtime globals and script locals.
- Produces a package accepted by both the reference CLI and Stackadia 1.3.2 Final.

## Security

- Does not extract before validating names and duplicates.
- Does not execute scripts, activate extensions, or load remote resources during inspection.
- Resets imported extension trust or clearly warns that trust is not portable.
- Applies reasonable resource limits appropriate to its environment.

## Evidence to return

Return the implementation version, operating system/runtime, conformance result log, SHA-256 of each fixture used, and the SHA-256 of one independently produced package. A useful final test is opening that independently produced package in both Stackadia Standalone and Lightweight Player.

