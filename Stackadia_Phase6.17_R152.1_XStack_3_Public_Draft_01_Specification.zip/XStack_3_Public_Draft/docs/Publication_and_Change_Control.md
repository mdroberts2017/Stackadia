# Publication and Change Control

## Recommended public locations

- Specification landing page: `/spec/xstack/3/`
- Manifest schema: `/spec/xstack/3/manifest.schema.json`
- Project schema 47: `/schema/project/47/project.schema.json`
- Conformance downloads: `/spec/xstack/3/conformance/`

The files in this package use placeholder `stackadia.example` schema identifiers. Replace that host once a permanent public domain is selected, then keep those identifiers stable.

## Release labels

- **Public Draft:** accurate description of shipped behavior, open for interoperability feedback.
- **Candidate:** no known technical ambiguities; at least one independent implementation has been tested.
- **Stable 3.0:** independent implementation passes the kit, permanent URLs exist, and changes require a published erratum or new version.

## Change rules

Editorial clarifications that do not alter accepted files may be published as errata. New optional project members can be documented in a schema-profile revision. Changes to archive mechanics require a new package version. Breaking data-model changes require a new project schema.

Every publication should retain older specifications, schemas, and conformance kits at their original URLs. Never replace a previously published fixture with different bytes under the same filename; add a new fixture and record it in the changelog.

## Feedback template

Reports should include:

- specification version and file SHA-256;
- implementation name and version;
- package or fixture name and SHA-256;
- expected and observed result;
- the smallest reproducible package, if disclosure is safe;
- whether the issue concerns archive, structure, integrity, migration, rendering, scripting, or extensions.

